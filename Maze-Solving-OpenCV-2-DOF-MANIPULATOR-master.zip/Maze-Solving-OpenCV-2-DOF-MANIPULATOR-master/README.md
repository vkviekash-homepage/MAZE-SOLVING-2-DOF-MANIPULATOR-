# Maze-Solving-OpenCV
Solving Simple mazes using contour detection and image processing and sending the coordinates to arduino via serial communication to control a 2 DOF manipulator and solve a the maze in real time.

I was a part of the team which conducted a workshop on this project in our college.

WOKING VIDEO LINK: https://youtu.be/bDIQAKLgUPg

